/* Isabella Kuhl 12/2/19
*  This program takes in a text file containing flight paths and costs
*  and outputs a file containing the minimum cost to travel to every
*  airport at least once as well as the shortest path, with each line representing
*  the next city to travel to */

#include <fstream>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <string>
#include <set>
#include <map>

using namespace std;

int main()
{
	string src;	// origin city
	string dest; // destination city
	string cost; // cost associated with travelling i.e. airfare, gas, etc
	map <string, map<string,int>> travelData; // map containing src, dest, and cost values
	set<string> cities; // set containing possible cities
	int minCost = 15000; // reference value for starting minimum cost
	int totalCost = 0; // total cost of trip
	string currSource = "ETCW"; // origin city
	string nextSource; // next city we travel to
	vector<string> optimalPath; // vector of best travel path
	optimalPath.push_back(currSource); // start travel path with origin city

	ifstream inFile;
	inFile.open("map.txt"); // contains travel info
	ofstream output;
	output.open("path.txt"); // solution

	for (int y = 0; y < 1346039; y++)	// for each line of file get relevant info
	{
		getline(inFile, src, ' ');
		getline(inFile, dest, ':');
		getline(inFile, cost);
		cities.insert(src);
		travelData[src][dest.substr(4,4)] = atoi(cost.c_str()); // insert into map of travel data
	}

	cities.erase(currSource); // remove origin from list
	set<string>::iterator it;
	for (int i = 0; i < 1494; i++) { // number of cities we're able to travel to
		for (it = cities.begin(); it != cities.end(); ++it) {
			if (travelData[currSource][*it] != 0 &&
						travelData[currSource][*it] < minCost) { // check if current traveling cost is less than current minCost
				minCost = travelData[currSource][*it]; // update min cost
				nextSource = *it; // look at next city
			}
		}
		optimalPath.push_back(nextSource); // add the cheapest dest to optimal path
		currSource = nextSource; // the origin becomes the cheapest destination
 		cities.erase(currSource); // remove city from set
 		totalCost += minCost; // update total cost
 		minCost = 15000; // reset minimum cost reference
	}

	totalCost += travelData[currSource]["ETCW"]; // add cost from current source to origin
	output << totalCost << endl; // output total cost
	optimalPath.push_back("ETCW"); // the last destination of path is origin

	for (int i = 0; i < optimalPath.size(); i++)
	{
		output << optimalPath[i] << endl; // output optimal path
	}
	output << "The way I approached my solution to this problem is that I implemented a greedy algorithm to look at \n"
	"one city at a time. After going through the map.txt file and extracting the information I needed,\n"
	"I then start at the origin and run through the possible destinations to see which path is the least\n"
	"amount of money. Once found, this destination becomes my origin and I continue until I have gone through\n"
	"every possible city." << endl;
}
